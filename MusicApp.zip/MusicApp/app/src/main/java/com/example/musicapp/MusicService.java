package com.example.musicapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;

import java.io.IOException;

public class MusicService extends Service {
    MediaPlayer player = new MediaPlayer(); // MediaPlayer 선언

    NotificationManager notificationManager; // notification 클래스
    NotificationChannel mChannel;
    Notification noti;
    Notification.Builder notiBuilder;

    public String folderPath; // 파일의 경로
    boolean isService = false; // 서비스가 처음 실행인지 저장

    public class LocalBinder extends Binder {
        MusicService getService() {
            return MusicService.this;
        }
    }

    private final IBinder mBinder = new LocalBinder(); // Binder 클래스의 객체 생성

    @Override
    public void onCreate() {
        player.setLooping(true);

        if (Build.VERSION.SDK_INT >= 26) { // Service를 Foreground로 실행하기 위한 과정

            // NotificationChannel(String id, CharSequence name, int importance);
            mChannel = new NotificationChannel("music_service_channel_id",
                    "music_service_channel",
                    NotificationManager.IMPORTANCE_DEFAULT);
            mChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

            // 노티피케이션 매니저 초기화
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            // 노티피케이션 채널 생성
            notificationManager.createNotificationChannel(mChannel);
            // 노티피케이션 빌더 객체 생성
            notiBuilder = new Notification.Builder(this, mChannel.getId());
        } else {
            // 노티피케이션 빌더 객체 생성
            notiBuilder = new Notification.Builder(this);
        }

        Intent intent = new Intent(this, MainActivity.class); // MainActivity 클래스를 실행하기 위한 Intent 객체
        // Activity를 실행하기 위한 PendingIntent
        PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Notification.Builder 객체를 이용하여 Notification 객체 생성
        noti = notiBuilder.setContentTitle("음악 재생 중")
                .setContentText("")
                .setSmallIcon(R.drawable.baseline_music_note_black_18dp)
                .setContentIntent(pIntent)
                .build();

        startForeground(123, noti);
        // foregound service 설정 - startForeground() 메소드 호출, 위에서 생성한 nofication 객체 넘겨줌
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        folderPath = intent.getStringExtra("path");
        // 메인액티비티에서 전달받아 절대 경로 String 값을 얻음
        player = new MediaPlayer();
        try {
            player.reset();
            player.setDataSource(folderPath); // MediaPlayer play 경로 설정
            player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        player.start(); // MediaPlayer play 시작
        isService = true;
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        player.stop(); // MediaPlayer play 중지

        player.release(); // MediaPlayer 객체 해제
        player = null;

    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    @Override
    public boolean onUnbind(Intent intent) { return false; }

    public void musicChange(String changepath) { // 음악이 바뀌는 경우 호출
        player.reset(); // MediaPlayer를 리셋
        folderPath = changepath;
        player = new MediaPlayer();
        try {
            player.reset();
            player.setDataSource(changepath); // 바뀐 경로로 MediaPlayer 설정
            player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        player.start(); // MediaPlayer 시작
    }
    public void musicReplay() {
        player.start();
    } // 음악을 재실행
    public void musicPause() {
        player.pause();
    } // 음악을 일시정지
    public void musicStop() {
        player.stop();
    } // 음악을 정지
    public boolean isPlaying() { // 현재 플레이 중인지 반환
        if (player != null)
            return player.isPlaying();
        else
            return false;
    }
    public boolean isStart() {
        return isService;
    } // 서비스를 시작한적이 있는지 반환
}