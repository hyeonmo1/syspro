package com.example.musicapp;

public class Music { // 음악 클래스
    public String path; // 파일 경로
    public String title; // 노래 제목
    public String singer; // 노래 가수

    Music(String p) {
        this.path = p;

        String[] words = p.split("-"); // 파일 경로로부터 제목 및 가수를 얻어냄
        words[1] = words[1].substring(0, words[1].length() - 4);
        words[0] = words[0].substring(26);
        this.title = words[1];
        this.singer = words[0];
    }
}
