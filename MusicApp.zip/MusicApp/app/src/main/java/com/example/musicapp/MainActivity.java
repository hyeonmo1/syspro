package com.example.musicapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    int playSeq = 0; // 플레이 중인 곡의 순서
    TextView nowplay; // 현재 재생곡
    ImageButton playbtn; // 플레이 버튼
    final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    boolean isPermitted = false; // 외부 저장소 허용 여부
    MusicService mService; // 서비스 객체
    boolean mBound = false;
    private File folder;
    private ListView m_ListView; // 리스트뷰
    private SimpleAdapter simpleAdapter; // 어댑터뷰
    ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>(); // 리스트뷰를 담을 변수
    HashMap<String, String> item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestRuntimePermission(); // Runtime permission 요청

        nowplay = findViewById(R.id.nowplay);
        playbtn = findViewById(R.id.play);

        if (isPermitted) { // 외부저장소 접근 허용이 가능하면 실행
            folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);

            for (int i = 0; i < folder.listFiles().length; i++) {
                // 리스트뷰에 저장할 아이템에 제목과 가수 저장
                Music m = new Music(folder.listFiles()[i].toString());
                item = new HashMap<String, String>();
                item.put("item 1", m.title);
                item.put("item 2", m.singer);
                list.add(item);
            }
            m_ListView = findViewById(R.id.musiclist); // 리스트뷰의 id를 받아옴
            registerForContextMenu(m_ListView); // 리스트뷰를 컨텍스트 메뉴에 등록
            simpleAdapter = new SimpleAdapter(this, list, android.R.layout.simple_list_item_2,
                    new String[]{"item 1", "item 2"},
                    new int[]{android.R.id.text1, android.R.id.text2}); // 항목이 두 개 있는 어댑터 생성
            m_ListView.setAdapter(simpleAdapter); // 어댑터 설정
            m_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView parent, View v, int position, long id) { // 리스트뷰 클릭 이벤트
                    playSeq = position;
                    if (!mService.isStart()) { // 서비스가 처음 실행되는 경우
                        playbtn.setImageResource(R.drawable.stop); // 버튼 이미지 설정
                        Music tmp = new Music(folder.listFiles()[playSeq].toString()); // 음악 객체에 현재 경로를 넘겨줌
                        Intent intent = new Intent(getApplicationContext(), MusicService.class);
                        intent.putExtra("path", tmp.path); // 인텐트를 만들어 파일 경로를 넘겨주고 startService
                        nowplay.setText(tmp.title + " - " + tmp.singer); // 현재 재생중인 음악 텍스트로 표시
                        startService(intent);
                    } else { // 서비스가 이미 실행된 적이 있는 경우
                        if (mService.isPlaying()) { // 음악이 실행중이면 멈춤
                            mService.musicStop();
                        }
                        playbtn.setImageResource(R.drawable.stop);
                        Music tmp = new Music(folder.listFiles()[playSeq].toString());
                        nowplay.setText(tmp.title + " - " + tmp.singer);
                        mService.musicChange(tmp.path); // 음악을 바꿔 재생
                    }
                }
            });
        }
    }


    public void onClick(View view) {
        // 재생,정지나 이전,다음곡 재생 버튼이 눌렸을 때 호출되는 onClick 메소드
        if (isPermitted) {
            switch (view.getId()) {
                case R.id.play: // 플레이 버튼
                    if (!mService.isStart()) { // 서비스가 처음 시작되는 경우
                        playbtn.setImageResource(R.drawable.stop);
                        Music tmp = new Music(folder.listFiles()[playSeq].toString());
                        Intent intent = new Intent(getApplicationContext(), MusicService.class);
                        intent.putExtra("path", tmp.path);
                        nowplay.setText(tmp.title + " - " + tmp.singer);
                        startService(intent);
                    } else { // 서비스가 이미 시작된 경우
                        if (mService.isPlaying()) { // 음악이 재생 중인 경우
                            playbtn.setImageResource(R.drawable.play);
                            mService.musicPause(); // 음악을 멈춤
                        } else { // 음악이 재생중이 아니면
                            playbtn.setImageResource(R.drawable.stop);
                            mService.musicReplay(); // 음악을 다시 재생
                        }
                    }
                    break;

                case R.id.prev: // 이전 곡 재생 버튼
                    if (!mService.isStart()) { // 서비스가 처음 시작되는 경우
                        playSeq = folder.listFiles().length - 1;
                        playbtn.setImageResource(R.drawable.stop);
                        Music tmp = new Music(folder.listFiles()[playSeq].toString());
                        Intent intent = new Intent(getApplicationContext(), MusicService.class);
                        intent.putExtra("path", tmp.path);
                        nowplay.setText(tmp.title + " - " + tmp.singer);
                        startService(intent);
                    } else {
                        playSeq--; // 플레이 순서를 설정
                        if (playSeq < 0) // 범위를 넘어가면 마지막 곡으로
                            playSeq = folder.listFiles().length - 1;
                        Music tmp = new Music(folder.listFiles()[playSeq].toString());
                        mService.musicChange(tmp.path); // 바뀐 음악 실행
                        nowplay.setText(tmp.title + " - " + tmp.singer);
                        playbtn.setImageResource(R.drawable.stop);
                    }
                    break;

                case R.id.next: // 다음 곡 재생 버튼
                    if (!mService.isStart()) { // 서비스가 처음 시작되는 경우
                        playSeq++;
                        playbtn.setImageResource(R.drawable.stop);
                        Music tmp = new Music(folder.listFiles()[playSeq].toString());
                        Intent intent = new Intent(getApplicationContext(), MusicService.class);
                        intent.putExtra("path", tmp.path);
                        nowplay.setText(tmp.title + " - " + tmp.singer);
                        startService(intent);
                    } else {
                        playSeq++;
                        if (playSeq >= folder.listFiles().length) // 범위를 넘어가면 처음 곡으로
                            playSeq = 0;
                        Music tmp2 = new Music(folder.listFiles()[playSeq].toString());
                        mService.musicChange(tmp2.path);
                        nowplay.setText(tmp2.title + " - " + tmp2.singer);
                        playbtn.setImageResource(R.drawable.stop);
                    }
                    break;
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) { // 종료 옵션이 있는 액션바
        getMenuInflater().inflate(R.menu.action_bar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) { // 액션바가 선택된 경우
        switch (item.getItemId()) {
            case R.id.quit:
                if (mService.isStart()) // 서비스가 실행된 적이 있으면
                    stopService(new Intent(this, MusicService.class));
                // stopservice 호출
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE); // bindService 호출
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mBound) { // unbindService 호출
            unbindService(mConnection);
            mBound = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mService.isStart()) // 서비스가 실행된 적이 있으면
            stopService(new Intent(this, MusicService.class)); // 서비스 종료
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        // Service에 연결(bound)되었을 때 호출되는 callback 메소드

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // IBinder 객체를 MusicService 클래스에 정의된 LocalBinder 클래스 객체로 캐스팅
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;

            mService = binder.getService(); // LocalService 객체를 참조하기 위해 LocalBinder 객체의 getService() 메소드 호출

            if (mService.folderPath != null) { // 실행 중인 서비스에 음악 경로가 있는 경우
                Music tmp = new Music(mService.folderPath); // 어떤 음악이 재생 중인지 확인하는 과정
                for (int i = 0; i < folder.listFiles().length; i++) {
                    if (tmp.path.equals(folder.listFiles()[i].toString()))
                        playSeq = i; // 음악의 순서를 알아냄
                }
                nowplay.setText(tmp.title + " - " + tmp.singer); // 실행중인 음악 텍스트뷰에 설정
                if (mService.isPlaying()) // 음악이 실행중 이었다면
                    playbtn.setImageResource(R.drawable.stop); // 버튼을 일시정지 이미지로 설정
            }
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) { // Service 연결 해제되었을 때 호출되는 callback 메소드

            mBound = false;
        }
    };

    private void requestRuntimePermission() { // 외부 저장소 접근 권한 요청

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
            }
        } else {
            isPermitted = true; // WRITE_EXTERNAL_STORAGE 권한이 있는 것
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    isPermitted = true; // WRITE_EXTERNAL_STORAGE 권한을 얻음

                } else { // 권한을 얻지 못하는 경우
                    isPermitted = false;
                }
                return;
            }
        }
    }
}